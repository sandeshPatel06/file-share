var R=require("../../../../chunks/[turbopack]_runtime.js")("server/app/api/uploads/[filename]/route.js")
R.c("server/chunks/[root-of-the-server]__09ikokf._.js")
R.c("server/chunks/[root-of-the-server]__0op9af~._.js")
R.c("server/chunks/node_modules_next_04~_e52._.js")
R.c("server/chunks/_next-internal_server_app_api_uploads_[filename]_route_actions_007g89h.js")
R.m(10607)
module.exports=R.m(10607).exports
